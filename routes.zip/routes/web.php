<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/welcome', function () {
    return view('welcome');
});

Route::get('/landingpage', function () {
    return view('inicio');
});

Route::get('/user', function () {
    return view('user');
});
Route::get('/desarollador1', function () {
    return view('desarollador1');
});
Route::get('/desarollador2', function () {
    return view('desarollador2');
});
Route::get('/welcome2', function () {
    return view('welcome2');
});

Route::get('/landingpage2', function () {
    return view('inicio2');
});