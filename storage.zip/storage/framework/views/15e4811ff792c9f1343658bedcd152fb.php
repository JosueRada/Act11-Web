<!DOCTYPE html>
<html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<head>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="welcome2" style="background-color: #D0FF5C;">Bienvenido</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="landingpage2">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="desarollador2">Desarolladores</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="welcome">LogOut</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="text-center">
  <img src="https://i.pinimg.com/originals/18/4c/51/184c515146b9a891c744ec9a266f2229.png" class="img-fluid" alt="Bienvenido">
</div>
</body>
<br>
<hr>
<div class="text-center">
  <a>Todos los derechos reservados a KaguyaAtEinein®</a><br>
  <a>Version 1.0.1</a>
</div>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Act9/resources/views/welcome2.blade.php ENDPATH**/ ?>