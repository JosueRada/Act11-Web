<!DOCTYPE html>
<html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<head>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="welcome">Bienvenido</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="landingpage">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="user">Usuarios</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="desarollador1" style="background-color: #D0FF5C;">Desarolladores</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="text-center">
<h1>Primero inicia sesion</h1>
  <img src="https://static.wikia.nocookie.net/0846a100-a8b4-4755-a95c-b5a7bf37d175" class="img-fluid" alt="Bienvenidon't">
</div>
</body>
<br>
<br>
<br>
<hr>
<div class="text-center">
  <a>Todos los derechos reservados a KaguyaAtEinein®</a><br>
  <a>Version 1.0.1</a>
</div>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Act9/resources/views/desarollador1.blade.php ENDPATH**/ ?>