<!DOCTYPE html>
<html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<head>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="welcome">Bienvenido</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="landingpage">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="user" style="background-color: #D0FF5C;">Usuarios</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="desarollador1">Desarolladores</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<form class="row g-3">
  <div class="col-md-4">
    <label for="validationServer01" class="form-label">Primer nombre</label>
    <input type="text" class="form-control" id="validationServer01" value="Mark" required>
    <div class="valid-feedback">
      Campo aceptado
    </div>
  </div>
  <div class="col-md-4">
    <label for="validationServer02" class="form-label">Ultimo nombre</label>
    <div class="input-group has-validation">
      <input type="text" class="form-control" id="validationServerUsername" value="Otto" required>
      <div id="validationServerUsernameFeedback" class="invalid-feedback">
        Por favor ingrese un nombre valido
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <label for="validationServerUsername" class="form-label">Nombre de usuario</label>
    <div class="input-group has-validation">
      <span class="input-group-text" id="inputGroupPrepend3">@</span>
      <input type="text" class="form-control" id="validationServerUsername" aria-describedby="inputGroupPrepend3 validationServerUsernameFeedback" required>
      <div id="validationServerUsernameFeedback" class="invalid-feedback">
        Por favor ingrese un nombre valido
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <label for="validationServer03" class="form-label">Ciudad</label>
    <input type="text" class="form-control" id="validationServer03" aria-describedby="validationServer03Feedback" required>
    <div id="validationServer03Feedback" class="invalid-feedback">
      Por favor ingrese una ciudad valida
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationServer04" class="form-label">Estado</label>
    <select class="form-select" id="validationServer04" aria-describedby="validationServer04Feedback" required>
      <option selected disabled value="">Elije</option>
      <option>Liquido</option>
      <option>Solido</option>
      <option>Gaseoso</option>
      <option>Plasma</option>
      <option>Si</option>
    </select>
    <div id="validationServer04Feedback" class="invalid-feedback">
      Por favor selecciona un estado valido
    </div>
  </div>
  <div class="col-12">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" value="" id="invalidCheck3" aria-describedby="invalidCheck3Feedback" required>
      <label class="form-check-label" for="invalidCheck3">
        Acepto los terminos y condiciones
      </label>
      <div id="invalidCheck3Feedback" class="invalid-feedback">
        Debes aceptar antes de enviar el formulario
      </div>
    </div>
  </div>
  <div class="col-12">
    <button class="btn btn-primary" type="submit">Enviar formulario</button>
  <a class="btn btn-primary" href="desarollador2">Enviar formulario (Link para entrar como desarollador)</a> 
  </div>
</body>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<hr>
<div class="text-center">
  <a>Todos los derechos reservados a KaguyaAtEinein®</a><br>
  <a>Version 1.0.1</a>
</div>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Act9/resources/views/user.blade.php ENDPATH**/ ?>